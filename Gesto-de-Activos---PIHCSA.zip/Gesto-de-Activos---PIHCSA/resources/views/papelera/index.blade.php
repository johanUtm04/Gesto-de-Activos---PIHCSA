@extends('adminlte::page')

@section('title', 'Perfil de Usuario')


@section('content')
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">
                        <i class="fas fa-user-cog"></i>
                        Papeleria 
                    </h3>
                </div>
@stop
